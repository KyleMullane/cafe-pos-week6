# Café POS & Delivery — Week 3 Solution (Strategy Pattern)

## Requirements
- Java 21
- Maven 3.9+

## Quick Start
### Run the demo (Unix/macOS/Linux)
mvn -q -DskipTests -Dexec.mainClass=com.cafepos.demo.Week3Demo exec:java

### Run the demo (Windows PowerShell) — if prefix parsing fails, use fully-qualified form
mvn -q -DskipTests org.codehaus.mojo:exec-maven-plugin:3.3.0:java `
  -Dexec.mainClass=com.cafepos.demo.Week3Demo

### Or compile then run with plain java
mvn -q -DskipTests compile
java -cp target/classes com.cafepos.demo.Week3Demo

### Run tests
mvn -q test
