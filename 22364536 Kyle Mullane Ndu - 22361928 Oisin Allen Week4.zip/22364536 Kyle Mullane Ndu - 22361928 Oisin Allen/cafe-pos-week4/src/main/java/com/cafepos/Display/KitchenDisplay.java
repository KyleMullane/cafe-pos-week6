package com.cafepos.Display;

import com.cafepos.order.Order;
import com.cafepos.order.OrderObserver;

public final class KitchenDisplay implements OrderObserver {
    @Override
    public void updated(Order order, String eventType) {
        if ("item has been added to Order".equals(eventType)) {
            System.out.println("Kitchen Order: " + order.getId() + " item added");
        } else if ("paid".equals(eventType)) {
            System.out.println("Kitchen Order: " + order.getId() + " payment received");
        }
    }
}