package com.cafepos.demo;

import com.cafepos.Display.CustomerNotifier;
import com.cafepos.Display.DeliveryDesk;
import com.cafepos.Display.KitchenDisplay;
import com.cafepos.catalog.Catalog;
import com.cafepos.catalog.InMemoryCatalog;
import com.cafepos.catalog.SimpleProduct;
import com.cafepos.common.Money;
import com.cafepos.order.LineItem;
import com.cafepos.order.Order;
import com.cafepos.order.OrderIds;
import com.cafepos.payment.CardPayment;
import com.cafepos.payment.CashPayment;
import com.cafepos.payment.WalletPayment;

import java.util.Scanner;

public final class Week3Demo /* <--Week 4 Demo */ {
    public static void main(String[] args) {
        Catalog catalog = new InMemoryCatalog();
        catalog.add(new SimpleProduct("P-ESP", "Espresso", Money.of(2.50)));
        catalog.add(new SimpleProduct("P-CAP", "Cappuccino", Money.of(2.50)));
        catalog.add(new SimpleProduct("P-CCK", "Cookie", Money.of(1.50)));

        Order order = new Order(OrderIds.next());
        order.registerOrderObserver(new KitchenDisplay());
        order.registerOrderObserver(new DeliveryDesk());
        order.registerOrderObserver(new CustomerNotifier());
        Scanner scanner = new Scanner(System.in);
        boolean addingItems = true;
        while (addingItems) {
            System.out.println("Select an item to add:");
            System.out.println("1) Espresso");
            System.out.println("2) Cappuccino");
            System.out.println("3) Chocolate Chip Cookie");
            System.out.println("4) Finish and proceed to payment");
            int menuChoice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            String selectedProductId = null;
            switch (menuChoice) {
                case 1:
                    selectedProductId = "P-ESP";
                    break;
                case 2:
                    selectedProductId = "P-CAP";
                    break;
                case 3:
                    selectedProductId = "P-CCK";
                    break;
                case 4:
                    addingItems = false;
                    continue;
                default:
                    System.out.println("Invalid option, please try again.");
                    continue;
            }

            if (selectedProductId != null) {
                System.out.print("Enter quantity: ");
                int qty = scanner.nextInt();
                scanner.nextLine(); // consume newline

                String finalProductId = selectedProductId;
                catalog.findById(finalProductId)
                        .ifPresentOrElse(
                                product -> order.addItem(new LineItem(product, qty)),
                                () -> System.out.println("Product not found!")
                        );
            }
        }

        // Simulate payment; should notify observers (customer, kitchen).
        System.out.println("Choose payment type: 1) Cash 2) Card 3) Wallet");
        int choice = scanner.nextInt();
        scanner.nextLine();
        switch (choice) {
            case 2:
                new CardPayment("1234567812341234").pay(order);
                break;
            case 3:
                new WalletPayment("1").pay(order);
                break;
            default:
                new CashPayment().pay(order);
        }

        System.out.println("----- RECEIPT -----");
        for (LineItem item : order.items()) {
            System.out.println(item.product().name() + " x" + item.quantity());
        }
        System.out.println("Item Cost: " + order.subtotal());
        System.out.println("SubTotal: " + order.totalWithTax(10));
        System.out.println("-------------------");

        // Mark order ready; should notify delivery and customer.
        order.markReady();
    }
}
