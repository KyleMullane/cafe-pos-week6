package com.cafepos.order;

import com.cafepos.payment.PaymentStrategy;

public interface OrderPublisher {
    void registerOrderObserver(OrderObserver o);
    void unregisterOrderObserver(OrderObserver o);
    void notifyObservers(String eventType);

    void addItem(LineItem li);

    void pay(PaymentStrategy strategy);

    void markReady();
}