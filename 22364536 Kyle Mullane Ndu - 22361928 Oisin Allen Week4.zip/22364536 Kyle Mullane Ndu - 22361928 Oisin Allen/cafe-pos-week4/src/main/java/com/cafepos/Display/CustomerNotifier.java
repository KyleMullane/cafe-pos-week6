package com.cafepos.Display;

import com.cafepos.order.Order;
import com.cafepos.order.OrderObserver;

public final class CustomerNotifier implements OrderObserver {
    @Override
    public void updated(Order order, String eventType) {
        System.out.println("Dear customer, your Order " + order.getId() + " has been updated: " + eventType + ".");
    }
}