package com.cafepos.Display;

import com.cafepos.order.Order;
import com.cafepos.order.OrderObserver;

public final class DeliveryDesk implements OrderObserver {
    @Override
    public void updated(Order order, String eventType) {
        if ("ready".equals(eventType)) {
            System.out.println("Delivery Order: " + order.getId() + " is ready for delivery");
        }
    }
}