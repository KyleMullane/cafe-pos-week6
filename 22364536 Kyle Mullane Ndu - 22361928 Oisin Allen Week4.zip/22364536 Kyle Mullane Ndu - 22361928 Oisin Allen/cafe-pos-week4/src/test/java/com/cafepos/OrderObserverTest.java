package com.cafepos;

import com.cafepos.catalog.*;
import com.cafepos.common.Money;
import com.cafepos.order.*;
import com.cafepos.payment.*;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

class OrderObserverTest {

    static class CaptureObserver implements OrderObserver {
        final List<String> events = new ArrayList<>();
        @Override
        public void updated(Order order, String eventType) {
            events.add(eventType);
        }
    }

    // --------- CASH PAYMENT TESTS ----------

    @Test
    void kitchenObserver_NotifiedEvents_CashPayment() {
        runTestForObserver(new CashPayment(), "itemAdded", "ready");
    }

    @Test
    void deliveryObserver_NotifiedEvents_CashPayment() {
        CaptureObserver observer = testObserverSequence(new CashPayment(), new String[] {"itemAdded", "ready"});
        assertEquals(List.of("itemAdded", "ready"), observer.events);
    }

    @Test
    void customerObserver_NotifiedEvents_CashPayment() {
        CaptureObserver observer = testObserverSequence(new CashPayment(), new String[] {"itemAdded", "ready"});
        assertEquals(List.of("itemAdded", "ready"), observer.events);
    }

    // --------- CARD PAYMENT TESTS ----------

    @Test
    void kitchenObserver_NotifiedEvents_CardPayment() {
        runTestForObserver(new CardPayment("1234567812341234"), "itemAdded", "ready");
    }

    @Test
    void deliveryObserver_NotifiedEvents_CardPayment() {
        CaptureObserver observer = testObserverSequence(new CardPayment("1234567812341234"), new String[] {"itemAdded", "ready"});
        assertEquals(List.of("itemAdded", "ready"), observer.events);
    }

    @Test
    void customerObserver_NotifiedEvents_CardPayment() {
        CaptureObserver observer = testObserverSequence(new CardPayment("1234567812341234"), new String[] {"itemAdded", "ready"});
        assertEquals(List.of("itemAdded", "ready"), observer.events);
    }

    // --------- WALLET PAYMENT TESTS ----------

    @Test
    void kitchenObserver_NotifiedEvents_WalletPayment() {
        runTestForObserver(new WalletPayment("WALLET100"), "itemAdded", "ready");
    }

    @Test
    void deliveryObserver_NotifiedEvents_WalletPayment() {
        CaptureObserver observer = testObserverSequence(new WalletPayment("WALLET100"), new String[] {"itemAdded", "ready"});
        assertEquals(List.of("itemAdded", "ready"), observer.events);
    }

    @Test
    void customerObserver_NotifiedEvents_WalletPayment() {
        CaptureObserver observer = testObserverSequence(new WalletPayment("WALLET100"), new String[] {"itemAdded", "ready"});
        assertEquals(List.of("itemAdded", "ready"), observer.events);
    }

    // ----- Helpers ----- (helpers create common test steps — creating an order, registering observers and checking notifications — so individual test methods can just specify the specific payment method and the expected notification sequence.)

    private void runTestForObserver(PaymentStrategy payment, String... expectedEvents) {
        CaptureObserver observer = testObserverSequence(payment, expectedEvents);
        assertEquals(Arrays.asList(expectedEvents), observer.events);
    }

    private CaptureObserver testObserverSequence(PaymentStrategy payment, String[] expectedEvents) {
        Catalog catalog = new InMemoryCatalog();
        catalog.add(new SimpleProduct("P-ESP", "Espresso", Money.of(2.50)));
        Order order = new Order(42L);
        CaptureObserver observer = new CaptureObserver();

        order.registerOrderObserver(observer);

        catalog.findById("P-ESP").ifPresent(product ->
                order.addItem(new LineItem(product, 1))
        );
        payment.pay(order);
        order.markReady();

        return observer;
    }
}
