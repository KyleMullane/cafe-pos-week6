package com.cafepos.payment;

import com.cafepos.order.Order;

public final class CardPayment implements PaymentStrategy {
    private final String cardNumber;
    public CardPayment(String cardNumber) { this.cardNumber = cardNumber; }
    @Override
    public void pay(Order order) {
        System.out.println("Processing card payment for order #" + order.id());
        System.out.println("Card number: " + cardNumber.replaceAll("\\d{12}(\\d{4})", "************$1")); // Masked card number
        System.out.println("Amount charged: " + order.totalWithTax(10) + "EUR");
    }
}