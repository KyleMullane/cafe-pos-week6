package com.cafepos;

import static org.junit.jupiter.api.Assertions.*;

import com.cafepos.payment.CardPayment;
import com.cafepos.payment.CashPayment;
import com.cafepos.payment.PaymentStrategy;
import com.cafepos.payment.WalletPayment;
import org.junit.jupiter.api.Test;
import com.cafepos.order.Order;
import com.cafepos.order.LineItem;
import com.cafepos.catalog.SimpleProduct;
import com.cafepos.common.Money;

public class Week3Tests {

    @Test void paymentStrategyCalled() {
        var p = new SimpleProduct("A", "A", Money.of(5));
        var order = new Order(42);
        order.addItem(new LineItem(p, 1));
        final boolean[] called = {false};
        PaymentStrategy fake = o -> called[0] = true;
        order.pay(fake);
        assertTrue(called[0], "Payment strategy should be called");
    }

        @Test
        public void testCashPayment() {
            Order order = new Order(1);
            order.addItem(new LineItem(new SimpleProduct("P-ESP", "Espresso", Money.of(2.50)), 1));
            CashPayment cashPayment = new CashPayment();
            assertDoesNotThrow(() -> order.pay(cashPayment));
        }

        @Test
        public void testCardPayment() {
            Order order = new Order(2);
            order.addItem(new LineItem(new SimpleProduct("P-CCK", "Chocolate Cookie", Money.of(3.50)), 1));
            CardPayment cardPayment = new CardPayment("1234567812341234");
            assertDoesNotThrow(() -> order.pay(cardPayment));
        }
        @Test
        void testWalletPayment() {
            var product = new SimpleProduct("W", "WalletProduct", Money.of(3));
            var order = new Order(43);
            order.addItem(new LineItem(product, 2));

            WalletPayment walletPayment = new WalletPayment("W");

            order.pay(walletPayment);

            assertDoesNotThrow(() -> order.pay(walletPayment));
        }

        @Test
        void cardPaymentMasksCardNumber() {
            var p = new SimpleProduct("C", "CardProduct", Money.of(10));
            var order = new Order(44);
            order.addItem(new LineItem(p, 1));
            String cardNumber = "1234567812345678";
            CardPayment cardPayment = new CardPayment(cardNumber);

            // Capture the output
            java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream();
            System.setOut(new java.io.PrintStream(outputStream));

            order.pay(cardPayment);

            String output = outputStream.toString();
            System.setOut(System.out);

            // Check that card number is masked, revealing only last 4 digits
            assertTrue(output.contains("************5678"), "Card number should be masked in output");
            // Ensure full original card number is not in output
            assertFalse(output.contains(cardNumber), "Full card number should not be printed");
        }
    }
