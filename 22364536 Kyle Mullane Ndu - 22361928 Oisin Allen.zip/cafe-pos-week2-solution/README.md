# Café POS & Delivery — Week 2 Solution

## Requirements
- Java 21
- Maven 3.9+

## Quick Start
```bash
mvn -q -DskipTests exec:java -Dexec.mainClass=com.cafepos.demo.Week2Demo
mvn -q test
```

Expected demo output:
```
Order #1001
Items: 2
Subtotal: 8.50
Tax (10%): 0.85
Total: 9.35
```
