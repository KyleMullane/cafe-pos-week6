package com.example.Week2;

import java.math.BigDecimal;
import java.util.*;

public final class Order {
    private final long id;
    private final List<LineItem> items = new ArrayList<>();

    public Order(long id) {
        this.id = id;
    }

    public void addItem(LineItem li) {
        items.add(li);
    }

    public long id() { return id; }

    public List<LineItem> items() { return items; }

    public Money subtotal() {
        return items.stream()
                .map(LineItem::lineTotal)
                .reduce(Money.zero(), Money::add);
    }

    public Money taxAtPercent(int percent) {
        BigDecimal rate = BigDecimal.valueOf(percent).divide(BigDecimal.valueOf(100));
        return new Money(subtotal().amount().multiply(rate));
    }

    public Money totalWithTax(int percent) {
        return subtotal().add(taxAtPercent(percent));
    }
}
