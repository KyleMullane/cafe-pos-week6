package com.example.Week2;
public interface Product {
    String id();
    String name();
    Money basePrice();
}