package com.example.Week2;

import java.util.*;

public class InMemoryCatalog implements Catalog {
    private final Map<String, Product> products = new HashMap<>();

    @Override
    public void add(Product product) {
        products.put(product.id(), product);
    }

    @Override
    public Optional<Product> findById(String id) {
        return Optional.ofNullable(products.get(id));
    }
}
