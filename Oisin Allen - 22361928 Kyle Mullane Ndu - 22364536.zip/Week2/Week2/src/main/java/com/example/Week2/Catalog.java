package com.example.Week2;

import java.util.Optional;

public interface Catalog {
    void add(Product product);
    Optional<Product> findById(String id);
}
