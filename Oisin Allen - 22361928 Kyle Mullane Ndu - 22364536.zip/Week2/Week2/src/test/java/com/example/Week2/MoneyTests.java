package com.example.Week2;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class MoneyTests {

    @Test
    public void testAdd() {
        Money m1 = Money.of(1.00);
        Money m2 = Money.of(2.50);
        assertEquals(Money.of(3.50), m1.add(m2));
    }

    @Test
    public void testMultiply() {
        Money m = Money.of(2.00);
        assertEquals(Money.of(6.00), m.multiply(3));
    }

    @Test
    public void testEqualsAndHashCode() {
        Money m1 = Money.of(4.00);
        Money m2 = Money.of(4.00);
        assertEquals(m1, m2);
        assertEquals(m1.hashCode(), m2.hashCode());
    }
}
